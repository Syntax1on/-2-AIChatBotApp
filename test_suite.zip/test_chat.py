import unittest
import app

class ChatbotTestCase(unittest.TestCase):
    def setUp(self):
        app.app.testing = True
        self.client = app.app.test_client()

    def test_chat_response(self):
        response = self.client.post('/chat', json={"message": "Hello"})
        self.assertEqual(response.status_code, 200)
        self.assertIn("reply", response.json)

if __name__ == '__main__':
    unittest.main()