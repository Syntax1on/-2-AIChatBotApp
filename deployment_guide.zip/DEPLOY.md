# Deployment Guide

## Local Setup
1. Clone the repo or extract the zip.
2. Create a virtual environment and install dependencies:
   ```
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. Run the app:
   ```
   python app.py
   ```

## Docker
1. Build Docker image:
   ```
   docker build -t ai-chatbot .
   ```

2. Run Docker container:
   ```
   docker run -p 5000:5000 ai-chatbot
   ```

## Notes
- Make sure `OPENAI_API_KEY` is properly configured.