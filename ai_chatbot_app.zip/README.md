# AI Chatbot App

This is a simple chatbot app using OpenAI's GPT model and Flask.

## Setup

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Set your OpenAI API key as an environment variable:

```bash
export OPENAI_API_KEY="your-api-key-here"
```

3. Run the app:

```bash
python app.py
```

4. Send a POST request to `/chat` with JSON:

```json
{ "message": "Hello!" }
```